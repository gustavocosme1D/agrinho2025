let playerX; // Posição X do jogador
let playerY; // Posição Y do jogador
let playerSize = 50; // Tamanho do jogador (círculo)
let playerSpeed = 5; // Velocidade de movimento do jogador

let enemyX;    // Posição X do inimigo
let enemyY;    // Posição Y do inimigo
let enemySize = 30; // Tamanho do inimigo (quadrado)
let enemySpeed = 3; // Velocidade de movimento do inimigo

let score = 0; // Variável para armazenar os pontos
let lastPointTime = 0; // Tempo em que o último ponto foi ganho
let pointInterval = 1000; // Intervalo de tempo para ganhar pontos (em milissegundos)

function setup() {
  createCanvas(800, 600);
  playerX = width / 2;
  playerY = height / 2;

  // Define a posição inicial do inimigo aleatoriamente na tela
  enemyX = random(width);
  enemyY = random(height);
}

function draw() {
  background(220);

  // --- Desenha o jogador ---
  fill(255, 0, 0); // Vermelho
  ellipse(playerX, playerY, playerSize, playerSize);

  // --- Movimento do jogador ---
  if (keyIsDown(UP_ARROW) || keyIsDown(87)) {
    playerY -= playerSpeed;
  }
  if (keyIsDown(DOWN_ARROW) || keyIsDown(83)) {
    playerY += playerSpeed;
  }
  if (keyIsDown(LEFT_ARROW) || keyIsDown(65)) {
    playerX -= playerSpeed;
  }
  if (keyIsDown(RIGHT_ARROW) || keyIsDown(68)) {
    playerX += playerSpeed;
  }

  // --- Limites da tela para o jogador ---
  playerX = constrain(playerX, playerSize / 2, width - playerSize / 2);
  playerY = constrain(playerY, playerSize / 2, height - playerSize / 2);

  // --- Desenha o inimigo ---
  fill(0, 0, 255); // Azul
  rectMode(CENTER); // Desenha o retângulo a partir do centro
  rect(enemyX, enemyY, enemySize, enemySize);

  // --- Movimento do inimigo (simples: persegue o jogador) ---
  if (enemyX < playerX) {
    enemyX += enemySpeed;
  } else if (enemyX > playerX) {
    enemyX -= enemySpeed;
  }
  if (enemyY < playerY) {
    enemyY += enemySpeed;
  } else if (enemyY > playerY) {
    enemyY -= enemySpeed;
  }

  // --- Verificação de Colisão ---
  // Calcula a distância entre o centro do jogador e o centro do inimigo
  let d = dist(playerX, playerY, enemyX, enemyY);

  // Se a distância for menor que a soma dos raios (aproximado para um círculo e um quadrado)
  // Ou seja, se eles se tocarem (ou chegarem perto o suficiente)
  if (d < (playerSize / 2) + (enemySize / 2)) {
    // Se houver colisão, zera os pontos (ou você pode fazer o jogo parar)
    score = 0;
    // Reposiciona o inimigo para longe do jogador
    enemyX = random(width);
    enemyY = random(height);
  }

  // --- Sistema de Pontos ---
  // currentTime() retorna o tempo em milissegundos desde que o sketch começou
  if (millis() - lastPointTime > pointInterval) {
    score++; // Incrementa os pontos
    lastPointTime = millis(); // Atualiza o tempo do último ponto
  }

  // --- Exibe os pontos na tela ---
  fill(0); // Cor preta para o texto
  textSize(24); // Tamanho da fonte
  textAlign(LEFT, TOP); // Alinha o texto no canto superior esquerdo
  text("Pontos: " + score, 10, 10); // Exibe o texto "Pontos: X" na posição (10, 10)
}